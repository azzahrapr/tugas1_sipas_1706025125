package apap.tugasindividu1.sipas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SipasApplication {

	public static void main(String[] args) {
		SpringApplication.run(SipasApplication.class, args);
	}

}
