package apap.tugasindividu1.sipas.service;

import apap.tugasindividu1.sipas.model.DiagnosisPenyakitModel;
import apap.tugasindividu1.sipas.model.PasienDiagnosisModel;
import apap.tugasindividu1.sipas.repository.PasienDiagnosisDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PasienDiagnosisServiceImpl implements PasienDiagnosisService {

    @Autowired
    PasienDiagnosisDB pasienDiagnosisDB;

    @Override
    public void addPasienDiagnosis(PasienDiagnosisModel pasienDiagnosisModel){
        pasienDiagnosisDB.save(pasienDiagnosisModel);
    }

    @Override
    public PasienDiagnosisModel getPasienDiagnosisById(Long id){
        return pasienDiagnosisDB.findById(id).get();
    }

    @Override
    public List<PasienDiagnosisModel> getPasienDiagnosisByDiagnosis(DiagnosisPenyakitModel diagnosisPenyakitModel){
        return pasienDiagnosisDB.findPasienDiagnosisModelByDiagnosisPenyakitModel(diagnosisPenyakitModel);
    }

}
